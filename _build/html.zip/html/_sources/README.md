# Evaluation Metrics

![AIcrowd-Logo](https://raw.githubusercontent.com/AIcrowd/AIcrowd/master/app/assets/images/misc/aicrowd-horizontal.png)


This repository contains source code for our curious explorations around Evaluation Metrics. 
The project is currently hosted at [evaluation-metrics.aicrowd.com](https://evaluation-metrics.aicrowd.com)

If you would like to contribute to this repository, checkout [`CONTRIBUTE.MD`](CONTRIBUTE.md). If you would like to report an issue or provide a suggestion, start a new thread on the Issues tab.


# Authors

-   Pratham Prasoon
-   Siddhartha Laghuvarapu
-   Dipam Chakraborty
-   Sharada Mohanty
-   AIcrowd Community
